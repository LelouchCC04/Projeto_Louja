﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoIntegrador
{
    public partial class Categorias : Form
    {
        public Categorias()
        {
            InitializeComponent();
        }

        private void btn_Salvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_Nome.Text == string.Empty)
                {
                    MessageBox.Show("OBRIGATORIO POR O NOME DA CATEGORIA");
                }
                else
                {

                    SqlConnection sql = new SqlConnection(dados.SqlConexaoLouja);
                    sql.Open();

                    string inserir = "INSERT INTO categorias(nome,descricao) Values(@nome,@descricao)";

                    SqlCommand cmd = new SqlCommand(inserir, sql);

                    cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = txt_Nome.Text;
                    cmd.Parameters.Add("@descricao", SqlDbType.VarChar).Value = txt_Descricao.Text;

                    cmd.ExecuteNonQuery();
                    sql.Close();

                    MessageBox.Show("CATEGORIA SALVA COM SUCESSO");

                }
            }
            catch (Exception erro)
            {

                MessageBox.Show(erro.Message);
            }

        }

        private void btn_Voltar_Click(object sender, EventArgs e)
        {
            this.Hide();
            var menu = new Menu();
            menu.Show();
        }

        private void btn_Limpar_Click(object sender, EventArgs e)
        {
            txt_Nome.Clear();
            txt_Descricao.Clear();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txt_Descricao_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
