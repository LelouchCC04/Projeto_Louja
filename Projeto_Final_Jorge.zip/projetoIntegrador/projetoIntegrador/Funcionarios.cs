﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoIntegrador
{
    public partial class Funcionarios : Form
    {
        public Funcionarios()
        {
            InitializeComponent();
        }

        private void Funcionarios_Load(object sender, EventArgs e)
        {

        }

        private void btn_Cadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (mask_Cpf.Text == string.Empty || mask_Telefone.Text == string.Empty || txt_Nome.Text == string.Empty ||
                    mask_DataNasc.Text == string.Empty || txt_Senha_Fun.Text == string.Empty || txt_Usu_Fun.Text == string.Empty)
                {
                    MessageBox.Show("PREECHA TODOS OS CAMPOS!", "ERRO\n", MessageBoxButtons.OK);
                }
                else
                {
                    MessageBox.Show("FUNCIONARIO CADASTRADO");

                    //abrir conexão
                    SqlConnection con = new(dados.SqlConexaoLouja);
                    con.Open();
                    string sqlinserir = "INSERT INTO funcionario(nome,cpf,telefone,senha,usuario,data_nasc)" +
                        "VALUES (@nome,@cpf,@telefone,@senha,@usuario,@data_nasc)";
                    SqlCommand cmd = new(sqlinserir, con);
                    //especificar cada campo com seu valor da tela
                    cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = txt_Nome.Text;
                    cmd.Parameters.Add("@cpf", SqlDbType.VarChar).Value = mask_Cpf.Text;
                    cmd.Parameters.Add("@telefone", SqlDbType.VarChar).Value = mask_Telefone.Text;
                    cmd.Parameters.Add("@senha", SqlDbType.VarChar).Value = txt_Senha_Fun.Text;
                    cmd.Parameters.Add("@usuario", SqlDbType.VarChar).Value = txt_Usu_Fun.Text;
                    cmd.Parameters.Add("@data_nasc", SqlDbType.Date).Value = Convert.ToString(mask_DataNasc.Text);

                    //se tudo estver ok vai executar e inserir no banco
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("DADOS ENVIADOS COM SUCESSO!", "SUCESSO\n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();

                    //sera direcinado para a pag de login do Funcionario depois de ser cadastrado

                    this.Hide();
                    var loginFun = new Login();
                    loginFun.ShowDialog();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btn_Apagar_Click(object sender, EventArgs e)
        {
            mask_Cpf.Clear();
            mask_DataNasc.Clear();
            mask_Telefone.Clear();
            txt_Nome.Clear();
            txt_Senha_Fun.Clear();
            txt_Usu_Fun.Clear();

            txt_Nome.Focus();
        }

        private void btn_Voltar_Click(object sender, EventArgs e)
        {
            //Sera mandado para a tela de Menu Escolha
            this.Hide();
            var menuEscolha = new MenuEscolha();
            menuEscolha.Show();
        }

        private void txt_Senha_Fun_TextChanged(object sender, EventArgs e)
        {
            string input = txt_Senha_Fun.Text;

            // Coloca as restrições da senha
            bool hasNumber = Regex.IsMatch(input, @"\d");
            ;
            bool hasUppercase = Regex.IsMatch(input, @"[A-Z]");
            bool haslowercase = Regex.IsMatch(input, @"[a-z]");

            // Verifica se a senha do usuario contem os requisitos pedidos
            if (hasNumber && hasUppercase && haslowercase)
            {
                lbl_Check_Senha.Visible = true;
                lbl_Check_Senha.Text = "√";
                
                lbl_Mai.ForeColor = Color.Green;
                label13.ForeColor = Color.Green;

                lbl_Numero.ForeColor = Color.Green;
                lbl_Check_Senha.ForeColor = Color.Green;

                //MessageBox.Show("O texto contém um número, um caractere e uma letra maiúscula.");
            }
            else
            {
                lbl_Check_Senha.Visible = true;
                lbl_Check_Senha.Text = "X";
                
                lbl_Mai.ForeColor = Color.Red;
                label13.ForeColor = Color.Red;

                lbl_Numero.ForeColor = Color.Red;
                lbl_Check_Senha.ForeColor = Color.Red;
                //MessageBox.Show("O texto não atende aos critérios.");
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
    }
}
