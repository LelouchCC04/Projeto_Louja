﻿namespace projetoIntegrador
{
    partial class Carrinho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_Carrinho = new System.Windows.Forms.DataGridView();
            this.btn_Finalizar = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_Endereço = new System.Windows.Forms.Button();
            this.btn_Remover = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Carrinho)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_Carrinho
            // 
            this.dg_Carrinho.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dg_Carrinho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Carrinho.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dg_Carrinho.Location = new System.Drawing.Point(12, 12);
            this.dg_Carrinho.Name = "dg_Carrinho";
            this.dg_Carrinho.RowTemplate.Height = 25;
            this.dg_Carrinho.Size = new System.Drawing.Size(675, 444);
            this.dg_Carrinho.TabIndex = 0;
            this.dg_Carrinho.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_Carrinho_CellContentClick);
            // 
            // btn_Finalizar
            // 
            this.btn_Finalizar.Location = new System.Drawing.Point(42, 534);
            this.btn_Finalizar.Name = "btn_Finalizar";
            this.btn_Finalizar.Size = new System.Drawing.Size(622, 36);
            this.btn_Finalizar.TabIndex = 1;
            this.btn_Finalizar.Text = "FINALIZAR";
            this.btn_Finalizar.UseVisualStyleBackColor = true;
            this.btn_Finalizar.Click += new System.EventHandler(this.btn_Finalizar_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(69, 474);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(114, 35);
            this.button3.TabIndex = 3;
            this.button3.Text = "ADICIONAR";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_Endereço
            // 
            this.btn_Endereço.Location = new System.Drawing.Point(524, 474);
            this.btn_Endereço.Name = "btn_Endereço";
            this.btn_Endereço.Size = new System.Drawing.Size(114, 35);
            this.btn_Endereço.TabIndex = 4;
            this.btn_Endereço.Text = "ENDEREÇO";
            this.btn_Endereço.UseVisualStyleBackColor = true;
            this.btn_Endereço.Click += new System.EventHandler(this.btn_Endereço_Click);
            // 
            // btn_Remover
            // 
            this.btn_Remover.Location = new System.Drawing.Point(296, 474);
            this.btn_Remover.Name = "btn_Remover";
            this.btn_Remover.Size = new System.Drawing.Size(114, 35);
            this.btn_Remover.TabIndex = 5;
            this.btn_Remover.Text = "REMOVER";
            this.btn_Remover.UseVisualStyleBackColor = true;
            this.btn_Remover.Click += new System.EventHandler(this.btn_Remover_Click);
            // 
            // Carrinho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 589);
            this.Controls.Add(this.btn_Remover);
            this.Controls.Add(this.btn_Endereço);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btn_Finalizar);
            this.Controls.Add(this.dg_Carrinho);
            this.Name = "Carrinho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Carrinho";
            ((System.ComponentModel.ISupportInitialize)(this.dg_Carrinho)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DataGridView dg_Carrinho;
        private Button btn_Finalizar;
        private Button button3;
        private Button btn_Endereço;
        private Button btn_Remover;
    }
}