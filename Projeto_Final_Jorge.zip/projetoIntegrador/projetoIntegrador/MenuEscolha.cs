﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoIntegrador
{
    public partial class MenuEscolha : Form
    {
        public MenuEscolha()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var login = new Login();
            login.ShowDialog();
        }

        private void btn_Cliente_Click(object sender, EventArgs e)
        {
            this.Hide();
            var loginCliente = new LoginCliente();
            loginCliente.ShowDialog();
        }

        private void btn_Cadastro_Click(object sender, EventArgs e)
        {
            this.Hide();
            var cadastrar = new Cliente();
            cadastrar.ShowDialog();
        }
    }
}
