﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoIntegrador
{
    public partial class endereco : Form
    {
        public endereco()
        {
            InitializeComponent();
            //vai carregar lista UF
            cb_Uf.DataSource = CarregarUF();
            //exibir a sigla da UF
            cb_Uf.DisplayMember = "sigla";
            //valor do elemento UF
            cb_Uf.ValueMember = "iduf";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public static DataTable CarregarUF()
        {
            try
            {
                //abrir conexão com o banco de dados
                SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                con.Open();
                //vai armazenar na variavel sql o comando de selecionar tudo da tabela UF
                string sql = "SELECT * FROM uf";
                //executar um comando sql
                SqlCommand cmd = new SqlCommand(sql, con);
                //vai efetuar uma leitura dos dados
                SqlDataReader dr = cmd.ExecuteReader();
                //fazer tratamento da tabela
                DataTable dt = new DataTable();
                //vai carregar os dados obtidos na leitura
                dt.Load(dr);
                //vai retornar as informações para o cbUF
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btn_Cadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_Num.Text == string.Empty || cb_Uf.Text == string.Empty || txt_Cep.Text == string.Empty ||
                txt_Cidade.Text == string.Empty || txt_Bairro.Text == string.Empty ||
                txt_Rua.Text == string.Empty)
                {
                    MessageBox.Show("PREENCHA OS CAMPOS", "Sistema", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                }
                else
                {
                    
                    SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                    con.Open();
                    string sqlInsert = "Insert into endereco (rua, numero, cep, cidade, uf, bairro) " +
                        "values(@rua, @numero, @cep, @cidade, @uf, @bairro)";

                    SqlCommand cmd = new SqlCommand(sqlInsert, con);
                    
                    
                    cmd.Parameters.Add("@rua", SqlDbType.VarChar).Value = txt_Rua.Text;
                    cmd.Parameters.Add("@numero", SqlDbType.Int).Value = Convert.ToInt32(txt_Num.Text);
                    cmd.Parameters.Add("@cep", SqlDbType.VarChar).Value = txt_Cep.Text;
                    cmd.Parameters.Add("@cidade", SqlDbType.VarChar).Value = txt_Cidade.Text;
                    cmd.Parameters.Add("@uf", SqlDbType.VarChar).Value = cb_Uf.Text;
                    cmd.Parameters.Add("@bairro", SqlDbType.VarChar).Value = txt_Bairro.Text;

                    // se tudo estiver ok, vai execultar o insert no banco
                    cmd.ExecuteNonQuery();
                    //MessageBox.Show("Endereço Inserido com sucesso", "Sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    con.Close();

                    lbl_Ender.Text = "ENDEREÇO ADICIONADO";
                    

                }
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);

            }
        }

        private void btn_Apagar_Click(object sender, EventArgs e)
        {
            txt_Bairro.Clear();
            txt_Cep.Clear();
            txt_Num.Clear();
            txt_Cidade.Clear();
            txt_Rua.Clear();
            cb_Uf.Text = "";
        }
    }
}
