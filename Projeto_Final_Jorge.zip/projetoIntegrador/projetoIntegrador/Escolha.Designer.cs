﻿namespace projetoIntegrador
{
    partial class Escolha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cb_Categoria = new System.Windows.Forms.ComboBox();
            this.categoriasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.produtoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txt_Qtd = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Total = new System.Windows.Forms.TextBox();
            this.dg_Nota = new System.Windows.Forms.DataGridView();
            this.carrinhoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_Add_Carrinho = new System.Windows.Forms.Button();
            this.btn_Limpar = new System.Windows.Forms.Button();
            this.txt_Codigo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Descricao = new System.Windows.Forms.TextBox();
            this.txt_Preco = new System.Windows.Forms.TextBox();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_Calcular = new System.Windows.Forms.Button();
            this.btn_Voltar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.categoriasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produtoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Nota)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrinhoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // cb_Categoria
            // 
            this.cb_Categoria.DataSource = this.categoriasBindingSource;
            this.cb_Categoria.Enabled = false;
            this.cb_Categoria.FormattingEnabled = true;
            this.cb_Categoria.Location = new System.Drawing.Point(213, 84);
            this.cb_Categoria.Name = "cb_Categoria";
            this.cb_Categoria.Size = new System.Drawing.Size(121, 23);
            this.cb_Categoria.TabIndex = 0;
            this.cb_Categoria.SelectedIndexChanged += new System.EventHandler(this.cb_Categoria_SelectedIndexChanged);
            // 
            // categoriasBindingSource
            // 
            this.categoriasBindingSource.DataSource = typeof(projetoIntegrador.Categorias);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(213, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "CATEGORIAS: ";
            // 
            // produtoBindingSource
            // 
            this.produtoBindingSource.DataSource = typeof(projetoIntegrador.Produto);
            // 
            // txt_Qtd
            // 
            this.txt_Qtd.Location = new System.Drawing.Point(208, 401);
            this.txt_Qtd.Name = "txt_Qtd";
            this.txt_Qtd.PlaceholderText = "0";
            this.txt_Qtd.Size = new System.Drawing.Size(121, 23);
            this.txt_Qtd.TabIndex = 4;
            this.txt_Qtd.TextChanged += new System.EventHandler(this.txt_Qtd_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(208, 383);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "QUANTIDADE: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 470);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "VALOR TOTAL: ";
            // 
            // txt_Total
            // 
            this.txt_Total.Enabled = false;
            this.txt_Total.Location = new System.Drawing.Point(12, 488);
            this.txt_Total.Name = "txt_Total";
            this.txt_Total.PlaceholderText = "R$ 00,00";
            this.txt_Total.Size = new System.Drawing.Size(118, 23);
            this.txt_Total.TabIndex = 7;
            this.txt_Total.TextChanged += new System.EventHandler(this.txt_Total_TextChanged);
            // 
            // dg_Nota
            // 
            this.dg_Nota.AllowUserToOrderColumns = true;
            this.dg_Nota.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Nota.Location = new System.Drawing.Point(410, 12);
            this.dg_Nota.Name = "dg_Nota";
            this.dg_Nota.RowTemplate.Height = 25;
            this.dg_Nota.Size = new System.Drawing.Size(497, 452);
            this.dg_Nota.TabIndex = 8;
            this.dg_Nota.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_Nota_CellContentClick);
            // 
            // carrinhoBindingSource
            // 
            this.carrinhoBindingSource.DataSource = typeof(projetoIntegrador.Carrinho);
            // 
            // btn_Add_Carrinho
            // 
            this.btn_Add_Carrinho.Location = new System.Drawing.Point(730, 470);
            this.btn_Add_Carrinho.Name = "btn_Add_Carrinho";
            this.btn_Add_Carrinho.Size = new System.Drawing.Size(102, 47);
            this.btn_Add_Carrinho.TabIndex = 12;
            this.btn_Add_Carrinho.Text = "ADD CARRINHO";
            this.btn_Add_Carrinho.UseVisualStyleBackColor = true;
            this.btn_Add_Carrinho.Click += new System.EventHandler(this.btn_Add_Carrinho_Click);
            // 
            // btn_Limpar
            // 
            this.btn_Limpar.Location = new System.Drawing.Point(592, 470);
            this.btn_Limpar.Name = "btn_Limpar";
            this.btn_Limpar.Size = new System.Drawing.Size(102, 47);
            this.btn_Limpar.TabIndex = 13;
            this.btn_Limpar.Text = "LIMPAR";
            this.btn_Limpar.UseVisualStyleBackColor = true;
            this.btn_Limpar.Click += new System.EventHandler(this.btn_Limpar_Click);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Enabled = false;
            this.txt_Codigo.Location = new System.Drawing.Point(12, 84);
            this.txt_Codigo.Name = "txt_Codigo";
            this.txt_Codigo.Size = new System.Drawing.Size(176, 23);
            this.txt_Codigo.TabIndex = 24;
            this.txt_Codigo.UseWaitCursor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 15);
            this.label6.TabIndex = 23;
            this.label6.Text = "CODIGO:";
            // 
            // txt_Descricao
            // 
            this.txt_Descricao.Enabled = false;
            this.txt_Descricao.Location = new System.Drawing.Point(12, 222);
            this.txt_Descricao.Multiline = true;
            this.txt_Descricao.Name = "txt_Descricao";
            this.txt_Descricao.PlaceholderText = "Sinopse: ";
            this.txt_Descricao.Size = new System.Drawing.Size(322, 88);
            this.txt_Descricao.TabIndex = 22;
            // 
            // txt_Preco
            // 
            this.txt_Preco.Enabled = false;
            this.txt_Preco.Location = new System.Drawing.Point(15, 401);
            this.txt_Preco.Name = "txt_Preco";
            this.txt_Preco.PlaceholderText = "R$ R$ 00,00";
            this.txt_Preco.Size = new System.Drawing.Size(146, 23);
            this.txt_Preco.TabIndex = 21;
            // 
            // txt_Nome
            // 
            this.txt_Nome.Enabled = false;
            this.txt_Nome.Location = new System.Drawing.Point(12, 150);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.PlaceholderText = "Nome";
            this.txt_Nome.Size = new System.Drawing.Size(322, 23);
            this.txt_Nome.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 15);
            this.label5.TabIndex = 19;
            this.label5.Text = "DESCRIÇÃO: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 383);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 15);
            this.label8.TabIndex = 17;
            this.label8.Text = "PREÇO:*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 132);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "NOME:*";
            // 
            // btn_Calcular
            // 
            this.btn_Calcular.Location = new System.Drawing.Point(223, 481);
            this.btn_Calcular.Name = "btn_Calcular";
            this.btn_Calcular.Size = new System.Drawing.Size(81, 36);
            this.btn_Calcular.TabIndex = 25;
            this.btn_Calcular.Text = "CALCULAR";
            this.btn_Calcular.UseVisualStyleBackColor = true;
            this.btn_Calcular.Click += new System.EventHandler(this.btn_Calcular_Click);
            // 
            // btn_Voltar
            // 
            this.btn_Voltar.Location = new System.Drawing.Point(12, 1);
            this.btn_Voltar.Name = "btn_Voltar";
            this.btn_Voltar.Size = new System.Drawing.Size(40, 23);
            this.btn_Voltar.TabIndex = 26;
            this.btn_Voltar.Text = "<==";
            this.btn_Voltar.UseVisualStyleBackColor = true;
            this.btn_Voltar.Click += new System.EventHandler(this.btn_Voltar_Click);
            // 
            // Escolha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(919, 529);
            this.Controls.Add(this.btn_Voltar);
            this.Controls.Add(this.btn_Calcular);
            this.Controls.Add(this.txt_Codigo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_Descricao);
            this.Controls.Add(this.txt_Preco);
            this.Controls.Add(this.txt_Nome);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btn_Limpar);
            this.Controls.Add(this.btn_Add_Carrinho);
            this.Controls.Add(this.dg_Nota);
            this.Controls.Add(this.txt_Total);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_Qtd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_Categoria);
            this.Name = "Escolha";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Escolha";
            this.Load += new System.EventHandler(this.Escolha_Load);
            ((System.ComponentModel.ISupportInitialize)(this.categoriasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produtoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Nota)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrinhoBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox cb_Categoria;
        private Label label1;
        private TextBox txt_Qtd;
        private Label label3;
        private Label label4;
        private TextBox txt_Total;
        private DataGridView dg_Nota;
        private Button btn_Add_Carrinho;
        private Button btn_Limpar;
        private BindingSource categoriasBindingSource;
        private BindingSource produtoBindingSource;
        private BindingSource carrinhoBindingSource;
        private TextBox txt_Codigo;
        private Label label6;
        private TextBox txt_Descricao;
        private TextBox txt_Preco;
        private TextBox txt_Nome;
        private Label label5;
        private Label label8;
        private Label label9;
        private PictureBox pictureBox1;
        private Button btn_Calcular;
        private Button btn_Voltar;
    }
}