﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace projetoIntegrador
{
    public partial class Escolha : Form
    {
        public Escolha()
        {
            InitializeComponent();
            AtualizarGrid();
            cb_Categoria.DataSource = CarregarCategoria();
            // cb_Categoria.ValueMember = "idcategorias";
            cb_Categoria.DisplayMember = "nome";
            
        }
        public static DataTable ListarProduto()//retorna o tipo de produto
        {
            try
            {
                SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                con.Open();
                string sql = "SELECT * FROM produto";
                SqlDataAdapter sda = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void AtualizarGrid()
        {
            //O comando datasource faz com que os dados vindos do ListarProduto(), carreguem dentro do DataGridView da lista
            dg_Nota.DataSource = ListarProduto();
            //montando o DataGridView com o cabeçalho
            dg_Nota.Columns[0].HeaderText = "id";
            dg_Nota.Columns[1].HeaderText = "Nome";
            //*dg_Nota.Columns[2].HeaderText = "quantidade";
            dg_Nota.Columns[3].HeaderText = "Preço";
            dg_Nota.Columns[4].HeaderText = "Descrição";
            dg_Nota.Columns[5].HeaderText = "imagem";
            //dg_Nota.Columns[6].HeaderText = "Gênero";
            //e tamanho das colunas
            dg_Nota.Columns[0].Width = 50;
            dg_Nota.Columns[1].Width = 150;
            //dg_Nota.Columns[2].Width = 50;
            dg_Nota.Columns[3].Width = 50;
            dg_Nota.Columns[4].Width = 130;
            dg_Nota.Columns[5].Width = 120;

            

            //dg_Nota.Columns[6].Width = 90;

            //faz com que selecione a linha toda do DataGridView
            dg_Nota.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //primissôes do usuario
            dg_Nota.AllowUserToAddRows = false;
            dg_Nota.AllowUserToDeleteRows = false;
            dg_Nota.ReadOnly = true;
        }
        private void btn_Add_Carrinho_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txt_Qtd.Text) || string.IsNullOrEmpty(txt_Codigo.Text))
                {
                    MessageBox.Show("Selecione um produto antes de adicionar ao carrinho.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    //abrindo conexão
                    SqlConnection sql = new SqlConnection(dados.SqlConexaoLouja);
                    sql.Open();

                    string inserir = "INSERT INTO compra(precoTotal, quantidade, nome) " +
                        "Values(@precoTotal, @quantidade, @nome)";
                    CarregarCategoria();
                    SqlCommand cmd = new SqlCommand(inserir, sql);


                    cmd.Parameters.Add("@precoTotal", SqlDbType.Decimal).Value = Convert.ToDecimal(txt_Total.Text);
                    cmd.Parameters.Add("@quantidade", SqlDbType.Int).Value = Convert.ToInt32(txt_Qtd.Text);
                    cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = txt_Nome.Text;



                    //se tudo estver ok vai executar e inserir no banco
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("PRODUTO ADICIONADO NO CARRINHO", "SUCESSO\n", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //fechando conexão
                    sql.Close();

                    //SE ESTIVER TUDO OK, ABRI O FORM CARRINHO
                    this.Hide();
                    var carrinho = new Carrinho();
                    carrinho.Show();

                }
            }
            catch (SqlException erro)
            {
                MessageBox.Show(erro.Message);
            }


        }

        private void btn_Limpar_Click(object sender, EventArgs e)
        {
            
            txt_Qtd.Text = string.Empty;
            txt_Total.Text = string.Empty;
            txt_Codigo.Text = string.Empty;
            txt_Descricao.Text = string.Empty;
            txt_Nome.Text = string.Empty;
            txt_Preco.Text = string.Empty;
            
        }

        private void Escolha_Load(object sender, EventArgs e)
        {

        }
        
        
        public static DataTable CarregarCategoria()
        {
            try
            {
                SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                con.Open();
                string sqlcategoria = "SELECT * FROM categorias";// WHERE nome=@nome AND idcategorias=@idcategorias
                SqlCommand cmd = new SqlCommand(sqlcategoria, con);
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                return dt;
            }
            catch (SqlException erro)
            {
                MessageBox.Show(erro.Message);
                return null;
            }
        }
       
        private void cb_Categoria_SelectedIndexChanged(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
            con.Open();

            string sql = "SELECT nome FROM categorias WHERE nome=@nome";
            SqlCommand cmd = new SqlCommand(sql, con);

           cmd.Parameters.Add("@nome", SqlDbType.Int).Value = cb_Categoria.Text;


            con.Close();
              
        }
       /* public void CalcularTotal()
        {

            decimal total = 0, preco = Convert.ToDecimal(txt_Preco.Text);
            int qtd = Convert.ToInt32(txt_Qtd.Text);

            total = preco * qtd;

            txt_Total.Text = total.ToString();

            
        }*/
        private void dg_Nota_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow linhas = dg_Nota.Rows[e.RowIndex];
                string id = linhas.Cells[0].Value.ToString();
                string nome = linhas.Cells[1].Value.ToString();
                
                string preco = linhas.Cells[3].Value.ToString();
                string descricao = linhas.Cells[4].Value.ToString();
               
                
                //MessageBox.Show($"ID: {id}\nNome: {nome}\nQuantidade: {quantidade}\nPreço: {preco}\nDescrição: {descricao}");
                txt_Codigo.Text = id;
                txt_Nome.Text = nome;
                txt_Descricao.Text = descricao;
                txt_Preco.Text = preco;
              


            }
        }

        private void txt_Total_TextChanged(object sender, EventArgs e)
        {
           /*int total = Convert.ToInt32(txt_Total.Text), resultado, qtd = Convert.ToInt32(txt_Qtd.Text);


            resultado = total * qtd;

            txt_Total.Text = resultado.ToString();
            MessageBox.Show(txt_Total.Text);*/
            //CalcularTotal();

        }

        private void txt_Qtd_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void btn_Calcular_Click(object sender, EventArgs e)
        {
            decimal total, preco = Convert.ToDecimal(txt_Preco.Text);
            int qtd = Convert.ToInt32(txt_Qtd.Text);
            if (qtd != 0)
            {

                total = preco * qtd;

                txt_Total.Text = total.ToString();
            }
            else
            {
                MessageBox.Show("Coloque a quantidade");
            }
            
        }

        private void btn_Voltar_Click(object sender, EventArgs e)
        {
            //Botao de voltar
            this.Hide();
            var menuFun = new MenuFuncionario();
            menuFun.Show();
        }
    }
}
