﻿namespace projetoIntegrador
{
    partial class MenuFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_escolha = new System.Windows.Forms.Button();
            this.btn_Cat = new System.Windows.Forms.Button();
            this.btn_Cliente = new System.Windows.Forms.Button();
            this.btn_Carrinho = new System.Windows.Forms.Button();
            this.btn_Produto = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_escolha
            // 
            this.btn_escolha.Location = new System.Drawing.Point(66, 281);
            this.btn_escolha.Name = "btn_escolha";
            this.btn_escolha.Size = new System.Drawing.Size(266, 33);
            this.btn_escolha.TabIndex = 9;
            this.btn_escolha.Text = "COMPRAR";
            this.btn_escolha.UseVisualStyleBackColor = true;
            this.btn_escolha.Click += new System.EventHandler(this.btn_escolha_Click);
            // 
            // btn_Cat
            // 
            this.btn_Cat.Location = new System.Drawing.Point(66, 203);
            this.btn_Cat.Name = "btn_Cat";
            this.btn_Cat.Size = new System.Drawing.Size(266, 33);
            this.btn_Cat.TabIndex = 8;
            this.btn_Cat.Text = "CATEGORIAS";
            this.btn_Cat.UseVisualStyleBackColor = true;
            this.btn_Cat.Click += new System.EventHandler(this.btn_Cat_Click);
            // 
            // btn_Cliente
            // 
            this.btn_Cliente.Location = new System.Drawing.Point(66, 415);
            this.btn_Cliente.Name = "btn_Cliente";
            this.btn_Cliente.Size = new System.Drawing.Size(266, 33);
            this.btn_Cliente.TabIndex = 7;
            this.btn_Cliente.Text = "MEUS DADOS";
            this.btn_Cliente.UseVisualStyleBackColor = true;
            this.btn_Cliente.Click += new System.EventHandler(this.btn_Cliente_Click);
            // 
            // btn_Carrinho
            // 
            this.btn_Carrinho.Location = new System.Drawing.Point(66, 356);
            this.btn_Carrinho.Name = "btn_Carrinho";
            this.btn_Carrinho.Size = new System.Drawing.Size(266, 33);
            this.btn_Carrinho.TabIndex = 6;
            this.btn_Carrinho.Text = "CARRINHO";
            this.btn_Carrinho.UseVisualStyleBackColor = true;
            this.btn_Carrinho.Click += new System.EventHandler(this.btn_Carrinho_Click);
            // 
            // btn_Produto
            // 
            this.btn_Produto.Location = new System.Drawing.Point(66, 141);
            this.btn_Produto.Name = "btn_Produto";
            this.btn_Produto.Size = new System.Drawing.Size(266, 33);
            this.btn_Produto.TabIndex = 5;
            this.btn_Produto.Text = "PRODUTO";
            this.btn_Produto.UseVisualStyleBackColor = true;
            this.btn_Produto.Click += new System.EventHandler(this.btn_Produto_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(146, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 30);
            this.label1.TabIndex = 10;
            this.label1.Text = "MENUS";
            // 
            // MenuFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(411, 503);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_escolha);
            this.Controls.Add(this.btn_Cat);
            this.Controls.Add(this.btn_Cliente);
            this.Controls.Add(this.btn_Carrinho);
            this.Controls.Add(this.btn_Produto);
            this.Name = "MenuFuncionario";
            this.Text = "MenuFuncionario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn_escolha;
        private Button btn_Cat;
        private Button btn_Cliente;
        private Button btn_Carrinho;
        private Button btn_Produto;
        private Label label1;
    }
}