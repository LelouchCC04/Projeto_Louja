﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoIntegrador
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void btn_Produto_Click(object sender, EventArgs e)
        {
            this.Hide();
            var produto = new Produto();
            produto.Show();
        }

        private void btn_Cliente_Click(object sender, EventArgs e)
        {
            /*this.Hide();
            var cliente = new Cliente();
            cliente.Show();*/
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_Cat_Click(object sender, EventArgs e)
        {
            this.Hide();
            var categoria = new Categorias();
            categoria.Show();
        }

        private void btn_escolha_Click(object sender, EventArgs e)
        {
            this.Hide();
            var escolha = new Escolha();
            escolha.Show();
        }

        private void btn_Carrinho_Click(object sender, EventArgs e)
        {
            this.Hide();
            var carrinho = new Carrinho();
            carrinho.Show();
        }
    }
}
