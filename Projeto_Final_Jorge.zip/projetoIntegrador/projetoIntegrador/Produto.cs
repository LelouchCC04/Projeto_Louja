﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoIntegrador
{
    public partial class Produto : Form
    {
        public Produto()
        {
            InitializeComponent();
            cb_Categoria.DataSource = CarregarCategoria();
            cb_Categoria.DisplayMember = "nome";
            AtualizarGrid();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        /*
        private Image GetImageFromBytes(byte[] imageBytes)
        {
            
            using (MemoryStream memoryStream = new MemoryStream(imageBytes))
            {
                return Image.FromStream(memoryStream);
            }
        }*/
        private void dg_Produtos_SelectionChanged(object sender, EventArgs e)
        {
           
        }


        public static DataTable CarregarCategoria()
        {
            try
            {
                SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                con.Open();
                string sqlcategoria = "SELECT * FROM categorias";// WHERE nome=@nome AND idcategorias=@idcategorias
                SqlCommand cmd = new SqlCommand(sqlcategoria, con);
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                return dt;
            }
            catch (SqlException erro)
            {
                MessageBox.Show(erro.Message);
                return null;
            }
        }

        public static DataTable ListarProduto()//retorna o tipo de produto
        {
            try
            {
                SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                con.Open();
                string sql = "SELECT * FROM produto";
                SqlDataAdapter sda = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void AtualizarGrid()
        {
            //O comando datasource faz com que os dados vindos do ListarProduto(), carreguem dentro do DataGridView da lista
            dg_Produtos.DataSource = ListarProduto();
            //montando o DataGridView com o cabeçalho
            dg_Produtos.Columns[0].HeaderText = "id";
            dg_Produtos.Columns[1].HeaderText = "Nome";
            dg_Produtos.Columns[2].HeaderText = "quantidade";
            dg_Produtos.Columns[3].HeaderText = "Preço";
            dg_Produtos.Columns[4].HeaderText = "Descrição";
            //dg_Nota.Columns[5].HeaderText = "Autor";
            //dg_Nota.Columns[6].HeaderText = "Gênero";
            //e tamanho das colunas
            dg_Produtos.Columns[0].Width = 50;
            dg_Produtos.Columns[1].Width = 150;
            dg_Produtos.Columns[2].Width = 50;
            dg_Produtos.Columns[3].Width = 50;
            dg_Produtos.Columns[4].Width = 160;
            //dg_Nota.Columns[5].Width = 120;
            //dg_Nota.Columns[6].Width = 90;



            //faz com que selecione a linha toda do DataGridView
            dg_Produtos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //primissôes do usuario
            dg_Produtos.AllowUserToAddRows = false;
            dg_Produtos.AllowUserToDeleteRows = false;
            dg_Produtos.ReadOnly = true;
        }
        private void btn_Cadastrar_Click(object sender, EventArgs e)
        {

            try
            {
                if (txt_Nome.Text == string.Empty || txt_Preco.Text == string.Empty || txt_Qtd.Text == string.Empty)
                {
                    MessageBox.Show("Preencha todos o campos com *");
                }
                else
                {
                    //abrindo conexão
                    SqlConnection sql = new SqlConnection(dados.SqlConexaoLouja);
                    sql.Open();

                    string inserir = "INSERT INTO produto(nome, quantidade, preco, descricao) " +
                        "Values(@nome, @quantidade, @preco, @descricao)";
                    CarregarCategoria();
                    SqlCommand cmd = new SqlCommand(inserir, sql);
                    //cmd.Parameters.Add("@categorias_idcategorias", SqlDbType.VarChar).Value = cb_Categoria.Text;
                    // cmd.Parameters.Add("@idproduto", SqlDbType.VarChar).Value = txt_Codigo.Text;
                    cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = txt_Nome.Text;
                    cmd.Parameters.Add("@quantidade", SqlDbType.Int).Value = txt_Qtd.Text;
                    cmd.Parameters.Add("@preco", SqlDbType.Decimal).Value = txt_Preco.Text;
                    cmd.Parameters.Add("@descricao", SqlDbType.VarChar).Value = txt_Descricao.Text;
                    

                    //se tudo estver ok vai executar e inserir no banco
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("DADOS ENVIADOS COM SUCESSO!", "SUCESSO\n", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //fechando conexão
                    sql.Close();

                }
            }
            catch (SqlException erro)
            {
                MessageBox.Show(erro.Message);
            }

        }

        private void btn_Limpar_Click(object sender, EventArgs e)
        {
            txt_Codigo.Text = string.Empty;
            txt_Descricao.Text = "";
            txt_Preco.Text = "";
            txt_Qtd.Text = "";
            txt_Nome.Text = string.Empty;
            cb_Categoria.Text = string.Empty;
            
        }

        private void btn_Voltar_Click(object sender, EventArgs e)
        {
            this.Hide();
            var menuFun = new MenuFuncionario();
            menuFun.Show();
        }

        private void cb_Categoria_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {

        }

        private void btn_Atualizar_Click(object sender, EventArgs e)
        {
            AtualizarGrid();
        }
        
        private void btn_CarregarImg_Click(object sender, EventArgs e)
        {
            
        }

        private void Produto_Load(object sender, EventArgs e)
        {

        }
        /*
        private byte[] GetImageBytes(Image image)
        {
            using (MemoryStream memoryStream = new MemoryStream())
            {
                image.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Jpeg);
                return memoryStream.ToArray();
            }
        }*/


        private void btn_SalvarImg_Click(object sender, EventArgs e)
        {
            
            
        }
        private int GetSelectedProductId()
        {
            if (dg_Produtos.SelectedRows.Count > 0)
            {
                // Obtém o valor da coluna "id" da linha selecionada
                return Convert.ToInt32(dg_Produtos.SelectedRows[0].Cells["idproduto"].Value);
            }

            // Retorna um valor padrão caso nenhum produto esteja selecionado
            return 0;
        }

        private void btn_CarregarImg_Click_1(object sender, EventArgs e)
        {

            //IMAGEM (NAO CONSEGUI IMPLEMENTAR A FUNÇÃO)
            /*
           try
            {
                if (pictureBox1.Image != null)
                {
                    byte[] imageBytes = GetImageBytes(pictureBox1.Image);

                    // Abrindo conexão
                    SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                    con.Open();

                    string sql = "UPDATE produto SET foto = @foto WHERE idproduto = @idproduto";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@foto", imageBytes);
                    cmd.Parameters.AddWithValue("@idproduto", txt_Codigo.Text);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Imagem salva com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Fechando conexão
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Selecione uma imagem para salvar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar a imagem: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }*/
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //IMAGEM(NAO CONSEGUI IMPLEMENTAR A FUNÇÃO)

            /*
            if (dg_Produtos.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dg_Produtos.SelectedRows[0];
                int productId = Convert.ToInt32(selectedRow.Cells["id"].Value);

                // Abrindo conexão
                SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                con.Open();

                string sql = "SELECT foto FROM produto WHERE idproduto = @idproduto";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@idproduto", productId);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        byte[] imageBytes = (byte[])reader["foto"];
                        Image image = GetImageFromBytes(imageBytes);
                        pictureBox1.Image = image;
                    }
                    else
                    {
                        pictureBox1.Image = null;
                    }
                }

                reader.Close();

                // Fechando conexão
                con.Close();
            }*/
        }

        private void btn_Remover_Click(object sender, EventArgs e)
        {


            // Remove o item selecionado


            if (dg_Produtos.SelectedRows.Count > 0)// Verifica o item selecionado
            {
                //Pergunta ao usuario se deseja remover
                DialogResult result = MessageBox.Show("Tem certeza de que deseja remover o produto selecionado?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    int selectedProductId = GetSelectedProductId();

                    if (selectedProductId > 0)
                    {
                        try
                        {
                            SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                            con.Open();

                            string sql = "DELETE FROM produto WHERE idproduto = @idproduto";
                            SqlCommand cmd = new SqlCommand(sql, con);
                            cmd.Parameters.AddWithValue("@idproduto", selectedProductId);
                            cmd.ExecuteNonQuery();

                            MessageBox.Show("Produto removido com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            con.Close();
                            AtualizarGrid();
                        }
                        catch (SqlException ex)
                        {
                            MessageBox.Show("Erro ao remover o produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecione um produto para remover.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
