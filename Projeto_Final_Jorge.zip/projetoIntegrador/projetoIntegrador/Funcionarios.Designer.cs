﻿namespace projetoIntegrador
{
    partial class Funcionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_Cadastrar = new System.Windows.Forms.Button();
            this.btn_Apagar = new System.Windows.Forms.Button();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.txt_Usu_Fun = new System.Windows.Forms.TextBox();
            this.txt_Senha_Fun = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.mask_Cpf = new System.Windows.Forms.MaskedTextBox();
            this.mask_Telefone = new System.Windows.Forms.MaskedTextBox();
            this.mask_DataNasc = new System.Windows.Forms.MaskedTextBox();
            this.btn_Voltar = new System.Windows.Forms.Button();
            this.lbl_Numero = new System.Windows.Forms.Label();
            this.lbl_Check_Senha = new System.Windows.Forms.Label();
            this.lbl_Mai = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(100, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(299, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "CADASTRO DE FUNCIONARIOS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "NOME:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(369, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "USUARIO:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(205, 342);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "SENHA:";
            // 
            // btn_Cadastrar
            // 
            this.btn_Cadastrar.Location = new System.Drawing.Point(308, 484);
            this.btn_Cadastrar.Name = "btn_Cadastrar";
            this.btn_Cadastrar.Size = new System.Drawing.Size(91, 39);
            this.btn_Cadastrar.TabIndex = 4;
            this.btn_Cadastrar.Text = "Cadastrar";
            this.btn_Cadastrar.UseVisualStyleBackColor = true;
            this.btn_Cadastrar.Click += new System.EventHandler(this.btn_Cadastrar_Click);
            // 
            // btn_Apagar
            // 
            this.btn_Apagar.Location = new System.Drawing.Point(154, 484);
            this.btn_Apagar.Name = "btn_Apagar";
            this.btn_Apagar.Size = new System.Drawing.Size(89, 39);
            this.btn_Apagar.TabIndex = 5;
            this.btn_Apagar.Text = "Apagar";
            this.btn_Apagar.UseVisualStyleBackColor = true;
            this.btn_Apagar.Click += new System.EventHandler(this.btn_Apagar_Click);
            // 
            // txt_Nome
            // 
            this.txt_Nome.Location = new System.Drawing.Point(49, 159);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(424, 23);
            this.txt_Nome.TabIndex = 6;
            // 
            // txt_Usu_Fun
            // 
            this.txt_Usu_Fun.Location = new System.Drawing.Point(369, 246);
            this.txt_Usu_Fun.Name = "txt_Usu_Fun";
            this.txt_Usu_Fun.Size = new System.Drawing.Size(100, 23);
            this.txt_Usu_Fun.TabIndex = 7;
            // 
            // txt_Senha_Fun
            // 
            this.txt_Senha_Fun.Location = new System.Drawing.Point(205, 360);
            this.txt_Senha_Fun.Name = "txt_Senha_Fun";
            this.txt_Senha_Fun.Size = new System.Drawing.Size(100, 23);
            this.txt_Senha_Fun.TabIndex = 8;
            this.txt_Senha_Fun.TextChanged += new System.EventHandler(this.txt_Senha_Fun_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(49, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "DATA NASCIMENTO:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(205, 217);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "TELEFONE:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(49, 217);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 15);
            this.label8.TabIndex = 13;
            this.label8.Text = "CPF:";
            // 
            // mask_Cpf
            // 
            this.mask_Cpf.Location = new System.Drawing.Point(49, 246);
            this.mask_Cpf.Mask = "000,000,000-00";
            this.mask_Cpf.Name = "mask_Cpf";
            this.mask_Cpf.Size = new System.Drawing.Size(100, 23);
            this.mask_Cpf.TabIndex = 14;
            // 
            // mask_Telefone
            // 
            this.mask_Telefone.Location = new System.Drawing.Point(205, 246);
            this.mask_Telefone.Mask = "(99) 0000-0000";
            this.mask_Telefone.Name = "mask_Telefone";
            this.mask_Telefone.Size = new System.Drawing.Size(100, 23);
            this.mask_Telefone.TabIndex = 15;
            // 
            // mask_DataNasc
            // 
            this.mask_DataNasc.Location = new System.Drawing.Point(49, 357);
            this.mask_DataNasc.Mask = "00/00/0000";
            this.mask_DataNasc.Name = "mask_DataNasc";
            this.mask_DataNasc.Size = new System.Drawing.Size(100, 23);
            this.mask_DataNasc.TabIndex = 16;
            this.mask_DataNasc.ValidatingType = typeof(System.DateTime);
            // 
            // btn_Voltar
            // 
            this.btn_Voltar.Location = new System.Drawing.Point(12, 12);
            this.btn_Voltar.Name = "btn_Voltar";
            this.btn_Voltar.Size = new System.Drawing.Size(45, 36);
            this.btn_Voltar.TabIndex = 19;
            this.btn_Voltar.Text = "<----";
            this.btn_Voltar.UseVisualStyleBackColor = true;
            this.btn_Voltar.Click += new System.EventHandler(this.btn_Voltar_Click);
            // 
            // lbl_Numero
            // 
            this.lbl_Numero.AutoSize = true;
            this.lbl_Numero.ForeColor = System.Drawing.Color.Red;
            this.lbl_Numero.Location = new System.Drawing.Point(367, 389);
            this.lbl_Numero.Name = "lbl_Numero";
            this.lbl_Numero.Size = new System.Drawing.Size(57, 15);
            this.lbl_Numero.TabIndex = 55;
            this.lbl_Numero.Text = "NUMERO";
            // 
            // lbl_Check_Senha
            // 
            this.lbl_Check_Senha.AutoSize = true;
            this.lbl_Check_Senha.ForeColor = System.Drawing.Color.Green;
            this.lbl_Check_Senha.Location = new System.Drawing.Point(321, 363);
            this.lbl_Check_Senha.Name = "lbl_Check_Senha";
            this.lbl_Check_Senha.Size = new System.Drawing.Size(15, 15);
            this.lbl_Check_Senha.TabIndex = 54;
            this.lbl_Check_Senha.Text = "√";
            this.lbl_Check_Senha.Visible = false;
            // 
            // lbl_Mai
            // 
            this.lbl_Mai.AutoSize = true;
            this.lbl_Mai.ForeColor = System.Drawing.Color.Red;
            this.lbl_Mai.Location = new System.Drawing.Point(393, 359);
            this.lbl_Mai.Name = "lbl_Mai";
            this.lbl_Mai.Size = new System.Drawing.Size(73, 15);
            this.lbl_Mai.TabIndex = 53;
            this.lbl_Mai.Text = "MAIUSCULA";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(259, 342);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 15);
            this.label9.TabIndex = 52;
            this.label9.Text = "(Tem que conter)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(393, 374);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 15);
            this.label13.TabIndex = 58;
            this.label13.Text = "MINUSCULA";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.SlateGray;
            this.label12.Location = new System.Drawing.Point(369, 342);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 15);
            this.label12.TabIndex = 60;
            this.label12.Text = "LETRAS";
            // 
            // Funcionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 547);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lbl_Numero);
            this.Controls.Add(this.lbl_Check_Senha);
            this.Controls.Add(this.lbl_Mai);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btn_Voltar);
            this.Controls.Add(this.mask_DataNasc);
            this.Controls.Add(this.mask_Telefone);
            this.Controls.Add(this.mask_Cpf);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_Senha_Fun);
            this.Controls.Add(this.txt_Usu_Fun);
            this.Controls.Add(this.txt_Nome);
            this.Controls.Add(this.btn_Apagar);
            this.Controls.Add(this.btn_Cadastrar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Funcionarios";
            this.Text = "Funcionarios";
            this.Load += new System.EventHandler(this.Funcionarios_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btn_Cadastrar;
        private Button btn_Apagar;
        private TextBox txt_Nome;
        private TextBox txt_Usu_Fun;
        private TextBox txt_Senha_Fun;
        private Label label5;
        private Label label6;
        private Label label8;
        private MaskedTextBox mask_Cpf;
        private MaskedTextBox mask_Telefone;
        private MaskedTextBox mask_DataNasc;
        private Button btn_Voltar;
        private Label lbl_Numero;
        private Label lbl_Check_Senha;
        private Label label7;
        private Label label9;
        private Label label13;
        private Label label12;
        private Label lbl_Mai;
    }
}