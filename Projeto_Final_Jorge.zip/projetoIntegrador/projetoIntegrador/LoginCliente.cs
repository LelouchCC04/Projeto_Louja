﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace projetoIntegrador
{
    public partial class LoginCliente : Form
    {
        public LoginCliente()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_senha_lo.Text == string.Empty || txt_usu_lo.Text == string.Empty)
                {
                    MessageBox.Show("POR FAVOR PREENCHE TODOS OS CAMPOS!");
                }
               
                else
                {
                    //abrindo conexão
                    SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                    con.Open();

                   
                    string sql = "SELECT usuario, senha FROM clients WHERE usuario=@usuario AND senha=@senha";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@usuario", txt_usu_lo.Text);
                    cmd.Parameters.AddWithValue("@senha", txt_senha_lo.Text);

                    cmd.ExecuteNonQuery();

                    SqlDataReader reader = cmd.ExecuteReader();

                    //VERIFICA SE O CLIENTE ESTA CADASTRADO
                    if (reader.HasRows){ 
                        MessageBox.Show("BEM VINDO DE VOLTA");
                        this.Hide();
                        var menu = new Menu();
                        menu.Show();
                    }

                    else
                    {
                        MessageBox.Show("Humm...Não consegui entrontrar nenhum usuario esse nome ou sua senha esta errada");
                    }

                    con.Close();

                }
            }
            catch (Exception erro)
            {

                MessageBox.Show(erro.Message);
            }
        }

        private void btn_Cadastro_Click(object sender, EventArgs e)
        {
            this.Hide();
            var cadastro = new Cliente();
            cadastro.Show();
        }

        private void btn_Apagar_Click(object sender, EventArgs e)
        {
            txt_senha_lo.Clear();
            txt_usu_lo.Clear();
        }

        private void LoginCliente_Load(object sender, EventArgs e)
        {

        }

        private void btn_Voltar_Click(object sender, EventArgs e)
        {
            //Sera mandado para a tela de Menu Escolha
            this.Hide();
            var menuEscolha = new MenuEscolha();
            menuEscolha.Show();
        }

        private void txt_senha_lo_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
