﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoIntegrador
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox2.Text == string.Empty || txt_usu_lo.Text == string.Empty)
                {
                    MessageBox.Show("POR FAVOR PREENCHE TODOS OS CAMPOS!");
                }
                else
                {
                    //abrindo conexão
                    SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                    con.Open();


                    string sql = "SELECT usuario, senha FROM funcionario WHERE usuario=@usuario AND senha=@senha";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@usuario", txt_usu_lo.Text);
                    cmd.Parameters.AddWithValue("@senha", textBox2.Text);

                    
                    //VERIFICA SE O FUNCIONARIO/FORNECEDOR ESTA CADASTRADO

                    // verificar se a consulta SQL retornou algum resultado
                    SqlDataReader reader = cmd.ExecuteReader();
                    // VERIFICA SE O FUNCIONARIO/FORNECEDOR ESTA CADASTRADO
                    if (reader.HasRows)
                    {
                        MessageBox.Show("BEM VINDO DE VOLTA");
                        this.Hide();
                        var menuFun = new MenuFuncionario();
                        menuFun.Show();
                    }
                    else
                    {
                        MessageBox.Show("Humm...Não consegui encontrar nenhum usuário com esse nome ou sua senha está errada");
                    }

                    con.Close();

                }
            }
            catch (SqlException erro)
            {
                MessageBox.Show("Ocorreu um erro durante a execução da consulta SQL: " + erro.Message);
            }
            catch (Exception erro)
            {
                MessageBox.Show("Ocorreu um erro: " + erro.Message);
            }
            
        }

        private void btn_Apagar_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            txt_usu_lo.Clear();
        }

        private void btn_Cadastro_Click(object sender, EventArgs e)
        {
            this.Hide();
            var cadastroFunc = new Funcionarios();
            cadastroFunc.Show();
        }

        private void txt_usu_lo_TextChanged(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btn_Voltar_Click(object sender, EventArgs e)
        {
            //Sera mandado para a tela de Menu Escolha
            this.Hide();
            var menuEscolha = new MenuEscolha();
            menuEscolha.Show();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
