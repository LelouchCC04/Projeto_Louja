﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoIntegrador
{
    public partial class Carrinho : Form
    {
        public Carrinho()
        {
            InitializeComponent();
            AtualizarGrid();
            Endereço();
        }
        public static DataTable ListarCompra()//retorna o tipo de produto
        {
            try
            {
                SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                con.Open();
                string sql = "SELECT * FROM compra";
                SqlDataAdapter sda = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        public void AtualizarGrid()
        {
            //O comando datasource faz com que os dados vindos do ListarProduto(), carreguem dentro do DataGridView da lista
            dg_Carrinho.DataSource = ListarCompra();
            

            //montando o DataGridView com o cabeçalho
            dg_Carrinho.Columns[0].HeaderText = "ID";
            dg_Carrinho.Columns[3].HeaderText = "Nome";
            dg_Carrinho.Columns[1].HeaderText = "Preço";
            dg_Carrinho.Columns[2].HeaderText = "Quantidade";

            //e tamanho das colunas
            

            dg_Carrinho.Columns[0].Width = 50;
            dg_Carrinho.Columns[3].Width = 150;
            dg_Carrinho.Columns[1].Width = 150;
            dg_Carrinho.Columns[2].Width = 70;

            //faz com que selecione a linha toda do DataGridView
            dg_Carrinho.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //primissôes do usuario
            dg_Carrinho.AllowUserToAddRows = false;
            dg_Carrinho.AllowUserToDeleteRows = false;
            dg_Carrinho.ReadOnly = true;
                
        }
        private void dg_Carrinho_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

           
        }
        private void button2_Click(object sender, EventArgs e)
        {
            //Sera mandado para a tela de Menu= do CLiente
            
        }

        private void btn_Finalizar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Compra finalizada com sucesso!");
            


        }
        public void Endereço()
        {
            SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
            con.Open();
            string sql = "SELECT * FROM endereco";


            con.Close();
            
        }

        private void btn_Endereço_Click(object sender, EventArgs e)
        {
            this.Hide();
            var endereco = new endereco();
            endereco.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            var compra = new Escolha();
            compra.Show();
        }
        private int GetSelectedProductId()
        {
            if (dg_Carrinho.SelectedRows.Count > 0)
            {
                // Obtém o valor da coluna "id" da linha selecionada
                return Convert.ToInt32(dg_Carrinho.SelectedRows[0].Cells["idcarrinho"].Value);
            }

            // Retorna um valor padrão caso nenhum produto esteja selecionado
            return 0;
        }
        private void btn_Remover_Click(object sender, EventArgs e)
        {
            if (dg_Carrinho.SelectedRows.Count > 0)// Verifica o item selecionado
            {
                //Pergunta ao usuario se deseja remover
                DialogResult result = MessageBox.Show("Tem certeza de que deseja remover o produto selecionado?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    int selectedProductId = GetSelectedProductId();

                    if (selectedProductId > 0)
                    {
                        try
                        {
                            SqlConnection con = new SqlConnection(dados.SqlConexaoLouja);
                            con.Open();

                            string sql = "DELETE FROM carrinho WHERE idcarrinho = @idcarrinho";
                            SqlCommand cmd = new SqlCommand(sql, con);
                            cmd.Parameters.AddWithValue("@idcarrinho", selectedProductId);
                            cmd.ExecuteNonQuery();

                            MessageBox.Show("Produto removido com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            con.Close();
                            AtualizarGrid();
                        }
                        catch (SqlException ex)
                        {
                            MessageBox.Show("Erro ao remover o produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecione um produto para remover.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
