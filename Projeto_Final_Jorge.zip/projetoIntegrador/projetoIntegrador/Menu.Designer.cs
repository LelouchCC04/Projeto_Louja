﻿namespace projetoIntegrador
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Carrinho = new System.Windows.Forms.Button();
            this.btn_escolha = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Carrinho
            // 
            this.btn_Carrinho.Location = new System.Drawing.Point(74, 257);
            this.btn_Carrinho.Name = "btn_Carrinho";
            this.btn_Carrinho.Size = new System.Drawing.Size(266, 33);
            this.btn_Carrinho.TabIndex = 1;
            this.btn_Carrinho.Text = "CARRINHO";
            this.btn_Carrinho.UseVisualStyleBackColor = true;
            this.btn_Carrinho.Click += new System.EventHandler(this.btn_Carrinho_Click);
            // 
            // btn_escolha
            // 
            this.btn_escolha.Location = new System.Drawing.Point(74, 122);
            this.btn_escolha.Name = "btn_escolha";
            this.btn_escolha.Size = new System.Drawing.Size(266, 33);
            this.btn_escolha.TabIndex = 4;
            this.btn_escolha.Text = "COMPRAR";
            this.btn_escolha.UseVisualStyleBackColor = true;
            this.btn_escolha.Click += new System.EventHandler(this.btn_escolha_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 425);
            this.Controls.Add(this.btn_escolha);
            this.Controls.Add(this.btn_Carrinho);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion
        private Button btn_Carrinho;
        private Button btn_escolha;
    }
}