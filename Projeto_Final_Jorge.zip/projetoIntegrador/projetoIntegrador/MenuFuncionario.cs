﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoIntegrador
{
    public partial class MenuFuncionario : Form
    {
        public MenuFuncionario()
        {
            InitializeComponent();
        }

        private void btn_Produto_Click(object sender, EventArgs e)
        {
            this.Hide();
            var produto = new Produto();
            produto.Show();
        }

        private void btn_Cat_Click(object sender, EventArgs e)
        {
            this.Hide();
            var categoria = new Categorias();
            categoria.Show();
        }

        private void btn_escolha_Click(object sender, EventArgs e)
        {
            this.Hide();
            var compra = new Escolha();
            compra.Show();
        }

        private void btn_Carrinho_Click(object sender, EventArgs e)
        {
            this.Hide();
            var carrinho = new Carrinho();
            carrinho.Show();
        }

        private void btn_Cliente_Click(object sender, EventArgs e)
        {
            //botao que manda para caadastro de Funcionarios
            this.Hide();
            var funcionarios = new Funcionarios();
            funcionarios.Show();
        }
    }
}
