﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projetoIntegrador
{
    internal class dados
    {
        public static string SqlConexaoLouja
        {
            get
            {
                return "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\jorge.gloliveira\\source\\repos\\projetoIntegrador\\louja.mdf;Integrated Security=True;Connect Timeout=30";
            }
        }
    }
}
