﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Text.RegularExpressions;

namespace projetoIntegrador
{
    public partial class Cliente : Form
    {
        public Cliente()
        {
            InitializeComponent();
        }

        private void btn_Cadastro_Click(object sender, EventArgs e)
        {
            try
            {
                if (mask_Cpf.Text == string.Empty || mask_Telefone.Text == string.Empty || txt_Nome.Text == string.Empty ||
                    mask_DataNasc.Text == string.Empty || txt_Senha_Cli.Text == string.Empty || txt_Usu_cli.Text == string.Empty)
                {
                    MessageBox.Show("PREECHA TODOS OS CAMPOS!", "ERRO\n", MessageBoxButtons.OK);
                }
                else
                {
                    MessageBox.Show("CLIENTE CADASTRADO");
                    
                    //abrir conexão
                    SqlConnection con = new(dados.SqlConexaoLouja);
                    con.Open();
                    string sqlinserir = "INSERT INTO clients(nome,cpf,telefone,senha,usuario,data_nasc)" +
                        "VALUES (@nome,@cpf,@telefone,@senha,@usuario,@data_nasc)";
                    SqlCommand cmd = new(sqlinserir, con);
                    //especificar cada campo com seu valor da tela
                    cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = txt_Nome.Text;
                    cmd.Parameters.Add("@cpf", SqlDbType.VarChar).Value = mask_Cpf.Text;
                    cmd.Parameters.Add("@telefone", SqlDbType.VarChar).Value = mask_Telefone.Text;
                    cmd.Parameters.Add("@senha", SqlDbType.VarChar).Value = txt_Senha_Cli.Text; 
                    cmd.Parameters.Add("@usuario", SqlDbType.VarChar).Value = txt_Usu_cli.Text;
                    cmd.Parameters.Add("@data_nasc", SqlDbType.Date).Value = Convert.ToString(mask_DataNasc.Text);
                    


                    //se tudo estver ok vai executar e inserir no banco
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("DADOS ENVIADOS COM SUCESSO!", "SUCESSO\n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();


                    //sera direcinado para a pag de login depois de ser cadastrado
                    this.Hide();
                    var loginCli = new LoginCliente();
                    loginCli.ShowDialog();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btn_Limpar_Click(object sender, EventArgs e)
        {
            txt_Nome.Clear();
            txt_Senha_Cli.Clear();
            txt_Usu_cli.Clear();

            mask_Cpf.Clear();
            mask_Telefone.Clear();
            mask_DataNasc.Clear();
            txt_Nome.Focus();

        }

        private void btn_Voltar_Click(object sender, EventArgs e)
        {
            //Sera mandado para a tela de login cliente
            this.Hide();
            var logincliente = new LoginCliente();
            logincliente.Show();
        }
        public static bool IsValidCpf(string cpf)
        {
            if (string.IsNullOrWhiteSpace(cpf))
                return false;

            // Remove qualquer caractere que não seja um número
            cpf = new string(cpf.Where(char.IsDigit).ToArray());

            // Verifica se o CPF possui 11 dígitos
            if (cpf.Length != 11)
                return false;

            // Verifica se todos os dígitos são iguais
            if (cpf.Distinct().Count() == 1)
                return false;

            // Calcula o primeiro dígito verificador
            int sum = 0;
            for (int i = 0; i < 9; i++)
            {
                sum += int.Parse(cpf[i].ToString()) * (10 - i);
            }
            int mod = sum % 11;
            int digit1 = mod < 2 ? 0 : 11 - mod;

            // Verifica se o primeiro dígito verificador está correto
            if (int.Parse(cpf[9].ToString()) != digit1)
                return false;

            // Calcula o segundo dígito verificador
            sum = 0;
            for (int i = 0; i < 10; i++)
            {
                sum += int.Parse(cpf[i].ToString()) * (11 - i);
            }
            mod = sum % 11;
            int digit2 = mod < 2 ? 0 : 11 - mod;

            // Verifica se o segundo dígito verificador está correto
            if (int.Parse(cpf[10].ToString()) != digit2)
                return false;

            return true;
        }

        private void mask_Cpf_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

            //verifica o cpf
            string cpf = mask_Cpf.Text;
            if (IsValidCpf(cpf))
            {
                lblCheck.Visible = true;
                lblCheck.Text = "√";
                lblCheck.ForeColor = Color.Green;
            }
            else
            {
                lblCheck.Visible = true;
                lblCheck.Text = "X";
                lblCheck.ForeColor = Color.Red;
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
        }
        private bool ValidaSenha(string vsenha)
        {
            return vsenha.Any(ch => !char.IsLetterOrDigit(ch));
        }
        private void txt_Senha_Cli_TextChanged(object sender, EventArgs e)
        {

            string input = txt_Senha_Cli.Text;

            // Coloca as restrições da senha
            bool hasNumber = Regex.IsMatch(input, @"\d");
            ;
            bool hasUppercase = Regex.IsMatch(input, @"[A-Z]");
            bool haslowercase = Regex.IsMatch(input, @"[a-z]");

            // Verifica se a senha do usuario contem os requisitos pedidos
            if (hasNumber && hasUppercase && haslowercase)
            {
                lbl_Check_Senha.Visible = true;
                lbl_Check_Senha.Text = "√";
                label8.ForeColor= Color.Green;
                
                lbl_Numero.ForeColor= Color.Green;
                lbl_Check_Senha.ForeColor = Color.Green;

                //MessageBox.Show("O texto contém um número, um caractere e uma letra maiúscula.");
            }
            else
            {
                lbl_Check_Senha.Visible = true;
                lbl_Check_Senha.Text = "X";
                label8.ForeColor = Color.Red;
                
                lbl_Numero.ForeColor = Color.Red;
                lbl_Check_Senha.ForeColor = Color.Red;
                //MessageBox.Show("O texto não atende aos critérios.");
            }
        }

        private void Cliente_Load(object sender, EventArgs e)
        {

        }

        private void lblCheck_Click(object sender, EventArgs e)
        {

        }
    }
}
