﻿CREATE TABLE cliente (
  idcliente INTEGER  NOT NULL   IDENTITY ,
  nome VARCHAR(50)  NOT NULL  ,
  telefone VARCHAR(14)  NOT NULL  ,
  cpf VARCHAR(11)  NOT NULL  ,
  senha VARCHAR(16)    ,
  usuario VARCHAR(16)      ,
  data_nasc DATE
PRIMARY KEY(idcliente));