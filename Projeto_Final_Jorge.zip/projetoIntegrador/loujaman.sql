﻿CREATE TABLE categorias (
  idcategorias INTEGER  NOT NULL   IDENTITY ,
  nome VARCHAR(20)  NOT NULL  ,
  descricao VARCHAR(50)      ,
PRIMARY KEY(idcategorias));




CREATE TABLE uf (
  iduf INTEGER  NOT NULL   IDENTITY ,
  sigla VARCHAR(2)      ,
PRIMARY KEY(iduf));




CREATE TABLE endereco (
  idendereco INTEGER  NOT NULL   IDENTITY ,
  uf_iduf INTEGER  NOT NULL  ,
  cidade VARCHAR(20)  NOT NULL  ,
  bairro VARCHAR(30)  NOT NULL  ,
  rua VARCHAR(30)  NOT NULL  ,
  numero INT  NOT NULL  ,
  cep VARCHAR(9)  NOT NULL    ,
PRIMARY KEY(idendereco)  ,
  FOREIGN KEY(uf_iduf)
    REFERENCES uf(iduf));


CREATE INDEX endereco_FKIndex1 ON endereco (uf_iduf);


CREATE INDEX IFK_Rel_06 ON endereco (uf_iduf);


CREATE TABLE produto (
  idproduto INTEGER  NOT NULL   IDENTITY ,
  categorias_idcategorias INTEGER  NOT NULL  ,
  nome VARCHAR(70)  NOT NULL  ,
  quantidade INT    ,
  preco DECIMAL  NOT NULL  ,
  descricao VARCHAR(200)      ,
PRIMARY KEY(idproduto)  ,
  FOREIGN KEY(categorias_idcategorias)
    REFERENCES categorias(idcategorias));



CREATE INDEX produto_FKIndex1 ON produto (categorias_idcategorias);



CREATE INDEX IFK_Rel_02 ON produto (categorias_idcategorias);



CREATE TABLE cliente (
  idcliente INTEGER  NOT NULL   IDENTITY ,
  endereco_idendereco INTEGER  NOT NULL  ,
  nome VARCHAR(50)  NOT NULL  ,
  telefone VARCHAR(14)  NOT NULL  ,
  cpf VARCHAR(11)  NOT NULL  ,
  senha VARCHAR(16)    ,
  usuario VARCHAR(16)      ,
PRIMARY KEY(idcliente)  ,
  FOREIGN KEY(endereco_idendereco)
    REFERENCES endereco(idendereco));



CREATE INDEX cliente_FKIndex1 ON cliente (endereco_idendereco);


CREATE INDEX IFK_Rel_04 ON cliente (endereco_idendereco);


CREATE TABLE carrinho (
  idcarrinho INTEGER  NOT NULL   IDENTITY ,
  produto_idproduto INTEGER  NOT NULL  ,
  cliente_idcliente INTEGER  NOT NULL    ,
PRIMARY KEY(idcarrinho)    ,
  FOREIGN KEY(cliente_idcliente)
    REFERENCES cliente(idcliente),
  FOREIGN KEY(produto_idproduto)
    REFERENCES produto(idproduto));


CREATE INDEX carrinho_FKIndex1 ON carrinho (cliente_idcliente);
CREATE INDEX carrinho_FKIndex2 ON carrinho (produto_idproduto);


CREATE INDEX IFK_Rel_01 ON carrinho (cliente_idcliente);
CREATE INDEX IFK_Rel_03 ON carrinho (produto_idproduto);


CREATE TABLE compra (
  idcompra INTEGER  NOT NULL   IDENTITY ,
  carrinho_idcarrinho INTEGER  NOT NULL  ,
  precoTotal DECIMAL  NOT NULL    ,
PRIMARY KEY(idcompra)  ,
  FOREIGN KEY(carrinho_idcarrinho)
    REFERENCES carrinho(idcarrinho));


CREATE INDEX compra_FKIndex1 ON compra (carrinho_idcarrinho);


CREATE INDEX IFK_Rel_05 ON compra (carrinho_idcarrinho);



